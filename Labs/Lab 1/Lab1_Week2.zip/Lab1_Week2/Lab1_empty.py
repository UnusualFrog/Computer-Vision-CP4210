import cv2

import matplotlib.pyplot as plt

from skimage.feature import hog
from skimage import data, exposure

#h_factor = how much should the image's height be scaled
#w_factor = how much should the image's width be scaled
def SIFT(h_factor, w_factor):
    #We want to match the features between two images

    
    # read the images 'book.jpg' and 'table.jpg'

    
    # convert images to grayscale

    
    # Scale the image in accordance to the arguments being passed in (h_factor, w_factor)
    # Check how well the SIFT technique performs when you rescale the image by various amounts

    
    #Use SIFT to match the features between the two images
    #I recommend you use two built-in objects (see online documentation)
    # - SIFT
    # - BFMatcher

    
    # show the image

    
def HOG():
    # Download a pre-existing image from the scikit-image toolbox
    image = data.astronaut() #Color image of the astronaut Eileen Collins

    #Rotate the image by however many degrees you choose
    

    # Use HOG technique
    

    # Visualize the results
    
    
def FAST():
    # Load the image ('book.jpg')
    

    #Rotate the image by however many degrees you choose

    
    # Create a FAST object
    # You can specify parameters like threshold, non-maximum suppression (NMS) status, etc.

    
    # Display the result (example, requires a display environment).
    # HINT: You can use a function (see online documentation for more info) inside the 'exposure' library (that is imported in the beginning of the code) to rescale the intensity of the result for better display.

    
def main():
    # Call the above three functions. Keep in mind that SIFT(...) requires two arguments.
    h_factor = 1; w_factor = 1;
    SIFT(h_factor, w_factor)
    HOG()
    FAST()


if __name__ == "__main__":
    main()
